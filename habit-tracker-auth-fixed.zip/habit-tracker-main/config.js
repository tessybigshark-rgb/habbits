"use strict";

window.APP_CONFIG = {
  supabaseUrl: "https://rktxluzpjwztsneaqcxb.supabase.co",
  supabaseAnonKey: "sb_publishable_PQedaRmIuHgUNVnvNN2VcQ_GV-G2aYO"
};
