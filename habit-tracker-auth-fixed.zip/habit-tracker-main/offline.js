"use strict";

/*
 * HabitFlow Offline Mode
 * Works alongside the existing Supabase-connected app.js.
 *
 * Storage: Browser localStorage
 * Charts: Existing custom charts.js
 */

(function () {
  const STORAGE_KEY = "habitflow_offline_v1";

  const state = {
    habits: [],
    completions: [],
    editingId: null
  };

  const $ = (selector) => document.querySelector(selector);

  function createId() {
    if (window.crypto && window.crypto.randomUUID) {
      return window.crypto.randomUUID();
    }

    return "offline-" + Date.now() + "-" +
      Math.random().toString(36).slice(2, 9);
  }

  function todayKey() {
    const now = new Date();

    return [
      now.getFullYear(),
      String(now.getMonth() + 1).padStart(2, "0"),
      String(now.getDate()).padStart(2, "0")
    ].join("-");
  }

  function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, (character) => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;"
    })[character]);
  }

  function loadData() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);

      if (!raw) return;

      const data = JSON.parse(raw);

      state.habits = Array.isArray(data.habits)
        ? data.habits
        : [];

      state.completions = Array.isArray(data.completions)
        ? data.completions
        : [];
    } catch (error) {
      console.error("HabitFlow offline data could not be loaded:", error);
      alert("Your offline data could not be loaded.");
    }
  }

  function saveData() {
    try {
      localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify({
          habits: state.habits,
          completions: state.completions,
          updatedAt: new Date().toISOString()
        })
      );

      return true;
    } catch (error) {
      console.error("HabitFlow offline save failed:", error);

      alert(
        "HabitFlow could not save your changes. " +
        "Check your browser's storage settings."
      );

      return false;
    }
  }

  function isCompleted(habitId, date = todayKey()) {
    return state.completions.some((item) =>
      String(item.habit_id) === String(habitId) &&
      item.completed_on === date
    );
  }

  function getStreak(habitId) {
    const completedDates = new Set(
      state.completions
        .filter((item) =>
          String(item.habit_id) === String(habitId)
        )
        .map((item) => item.completed_on)
    );

    const cursor = new Date();
    cursor.setHours(12, 0, 0, 0);

    // Allow a streak to continue if the user has not completed
    // the habit yet today.
    if (!completedDates.has(todayKey())) {
      cursor.setDate(cursor.getDate() - 1);
    }

    let streak = 0;

    for (let i = 0; i < 3660; i++) {
      const key = [
        cursor.getFullYear(),
        String(cursor.getMonth() + 1).padStart(2, "0"),
        String(cursor.getDate()).padStart(2, "0")
      ].join("-");

      if (!completedDates.has(key)) break;

      streak++;
      cursor.setDate(cursor.getDate() - 1);
    }

    return streak;
  }

  function renderCharts() {
    if (
      window.HabitFlowCharts &&
      typeof window.HabitFlowCharts.render === "function"
    ) {
      window.__habitFlowLastData = {
        habits: state.habits.slice(),
        completions: state.completions.slice()
      };

      window.HabitFlowCharts.render(
        state.habits,
        state.completions
      );
    } else {
      console.warn(
        "HabitFlow charts are unavailable. Check that charts.js loaded."
      );
    }
  }

  function renderOfflineHabits() {
    const list = $("#offlineHabitList");

    if (!list) return;

    if (!state.habits.length) {
      list.innerHTML = `
        <div class="offline-empty">
          <h3>🌱 Start with one small habit</h3>
          <p>Your offline habits will appear here.</p>
        </div>
      `;
    } else {
      list.innerHTML = state.habits.map((habit) => {
        const done = isCompleted(habit.id);

        return `
          <article class="offline-habit ${done ? "completed" : ""}">
            <div class="offline-habit-info">
              <strong>${escapeHTML(habit.icon || "🌱")}
                ${escapeHTML(habit.name)}
              </strong>

              <span>${escapeHTML(habit.category || "Personal")}</span>

              <small>
                ${done ? "Completed today ✓" : "Not completed today"}
                · 🔥 ${getStreak(habit.id)} day streak
              </small>
            </div>

            <div class="offline-habit-actions">
              <button
                type="button"
                data-offline-action="toggle"
                data-id="${escapeHTML(habit.id)}"
                aria-pressed="${done}">
                ${done ? "Undo" : "✓ Complete"}
              </button>

              <button
                type="button"
                data-offline-action="edit"
                data-id="${escapeHTML(habit.id)}">
                Edit
              </button>

              <button
                type="button"
                data-offline-action="delete"
                data-id="${escapeHTML(habit.id)}">
                Delete
              </button>
            </div>
          </article>
        `;
      }).join("");
    }

    const completed = state.habits.filter((habit) =>
      isCompleted(habit.id)
    ).length;

    const total = state.habits.length;

    const percent = total
      ? Math.round(completed / total * 100)
      : 0;

    const summary = $("#offlineSummary");

    if (summary) {
      summary.textContent =
        `${completed} of ${total} habits completed today · ${percent}%`;
    }

    renderCharts();
  }

  function resetForm() {
    const form = $("#offlineHabitForm");

    if (form) form.reset();

    state.editingId = null;

    const submit = $("#offlineSaveButton");

    if (submit) submit.textContent = "Add habit";

    const cancel = $("#offlineCancelButton");

    if (cancel) cancel.hidden = true;
  }

  function saveHabit(event) {
    event.preventDefault();

    const nameInput = $("#offlineHabitName");
    const categoryInput = $("#offlineHabitCategory");
    const iconInput = $("#offlineHabitIcon");

    const name = nameInput.value.trim();

    if (!name) {
      nameInput.focus();
      return;
    }

    if (name.length > 80) {
      alert("Habit names must be 80 characters or fewer.");
      return;
    }

    const category = categoryInput.value || "Personal";
    const icon = iconInput.value || "🌱";

    if (state.editingId) {
      const habit = state.habits.find(
        (item) => String(item.id) === String(state.editingId)
      );

      if (habit) {
        habit.name = name;
        habit.category = category;
        habit.icon = icon;
      }
    } else {
      state.habits.push({
        id: createId(),
        name,
        category,
        icon,
        created_at: new Date().toISOString()
      });
    }

    if (saveData()) {
      resetForm();
      renderOfflineHabits();
    }
  }

  function toggleHabit(id) {
    const habit = state.habits.find(
      (item) => String(item.id) === String(id)
    );

    if (!habit) return;

    const today = todayKey();

    const index = state.completions.findIndex((item) =>
      String(item.habit_id) === String(id) &&
      item.completed_on === today
    );

    if (index >= 0) {
      state.completions.splice(index, 1);
    } else {
      state.completions.push({
        id: createId(),
        habit_id: id,
        completed_on: today,
        created_at: new Date().toISOString()
      });
    }

    if (saveData()) renderOfflineHabits();
  }

  function editHabit(id) {
    const habit = state.habits.find(
      (item) => String(item.id) === String(id)
    );

    if (!habit) return;

    state.editingId = id;

    $("#offlineHabitName").value = habit.name;
    $("#offlineHabitCategory").value = habit.category || "Personal";
    $("#offlineHabitIcon").value = habit.icon || "🌱";

    $("#offlineSaveButton").textContent = "Save changes";
    $("#offlineCancelButton").hidden = false;

    $("#offlineHabitName").focus();
  }

  function deleteHabit(id) {
    const habit = state.habits.find(
      (item) => String(item.id) === String(id)
    );

    if (!habit) return;

    if (!confirm(`Delete "${habit.name}" and its offline history?`)) {
      return;
    }

    state.habits = state.habits.filter(
      (item) => String(item.id) !== String(id)
    );

    state.completions = state.completions.filter(
      (item) => String(item.habit_id) !== String(id)
    );

    if (saveData()) renderOfflineHabits();
  }

  function exportData() {
    const backup = {
      application: "HabitFlow Offline",
      version: 1,
      exportedAt: new Date().toISOString(),
      habits: state.habits,
      completions: state.completions
    };

    const blob = new Blob(
      [JSON.stringify(backup, null, 2)],
      { type: "application/json" }
    );

    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");

    link.href = url;
    link.download = `habitflow-offline-${todayKey()}.json`;
    link.click();

    URL.revokeObjectURL(url);
  }

  function importData(file) {
    if (!file) return;

    const reader = new FileReader();

    reader.onload = () => {
      try {
        const backup = JSON.parse(reader.result);

        if (
          !Array.isArray(backup.habits) ||
          !Array.isArray(backup.completions)
        ) {
          throw new Error("Invalid HabitFlow backup.");
        }

        if (!confirm("Replace your current offline data with this backup?")) {
          return;
        }

        state.habits = backup.habits;
        state.completions = backup.completions;

        if (saveData()) renderOfflineHabits();
      } catch (error) {
        console.error(error);
        alert("The selected file is not a valid HabitFlow backup.");
      }
    };

    reader.readAsText(file);
  }

  function addStyles() {
    const style = document.createElement("style");

    style.textContent = `
      .habitflow-offline-mode .welcome-row,
      .habitflow-offline-mode .stats-grid,
      .habitflow-offline-mode .content-grid {
        display: none !important;
      }

      #offlineDashboard {
        margin: 0 0 24px;
      }

      .offline-status {
        margin-bottom: 16px;
        padding: 12px 14px;
        border-radius: 12px;
        background: rgba(32, 167, 121, .12);
      }

      .offline-habit {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 14px;
        padding: 16px 0;
        border-bottom: 1px solid var(--border, #ddd);
      }

      .offline-habit-info {
        display: grid;
        gap: 5px;
        min-width: 0;
      }

      .offline-habit-info span,
      .offline-habit-info small {
        color: var(--muted, #777);
      }

      .offline-habit-actions {
        display: flex;
        flex-wrap: wrap;
        gap: 6px;
      }

      .offline-habit-actions button {
        padding: 8px 10px;
        border: 1px solid var(--border, #ddd);
        border-radius: 8px;
        background: var(--surface, #fff);
        color: inherit;
        cursor: pointer;
      }

      .offline-habit.completed {
        background: rgba(32, 167, 121, .05);
      }

      .offline-form-grid {
        display: grid;
        grid-template-columns: 2fr 1fr 1fr;
        gap: 12px;
      }

      .offline-form-grid label {
        display: grid;
        gap: 6px;
      }

      .offline-form-grid input,
      .offline-form-grid select {
        width: 100%;
        min-width: 0;
        padding: 10px;
        border: 1px solid var(--border, #ddd);
        border-radius: 8px;
      }

      .offline-toolbar {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
        margin-top: 16px;
      }

      .offline-empty {
        padding: 20px 0;
        text-align: center;
      }

      @media (max-width: 700px) {
        .offline-form-grid {
          grid-template-columns: 1fr;
        }

        .offline-habit {
          align-items: flex-start;
          flex-direction: column;
        }
      }
    `;

    document.head.appendChild(style);
  }

  function createDashboard() {
    const appPanel = $("#appPanel");
    const authPanel = $("#authPanel");

    if (!appPanel || !authPanel) {
      console.error("HabitFlow offline mode: required panels were not found.");
      return;
    }

    // Add the offline entry button below the existing sign-in form.
    if (!$("#offlineModeButton")) {
      const button = document.createElement("button");

      button.id = "offlineModeButton";
      button.type = "button";
      button.className = "button button-light full-width";
      button.style.marginTop = "12px";
      button.textContent = "Continue offline on this device";

      authPanel.appendChild(button);

      button.addEventListener("click", openOfflineMode);
    }

    // Create a separate local dashboard without replacing app.js.
    if (!$("#offlineDashboard")) {
      const section = document.createElement("section");

      section.id = "offlineDashboard";
      section.className = "panel hidden";

      section.innerHTML = `
        <div class="section-heading">
          <div>
            <p class="eyebrow">LOCAL MODE</p>
            <h2>HabitFlow Offline</h2>
            <p id="offlineSummary" class="muted">
              Your habits are stored on this device.
            </p>
          </div>
        </div>

        <div class="offline-status">
          📴 Offline mode: your changes are saved in this browser.
          They are not automatically synchronized with Supabase.
        </div>

        <form id="offlineHabitForm">
          <div class="offline-form-grid">
            <label>
              Habit name
              <input
                id="offlineHabitName"
                maxlength="80"
                required
                placeholder="e.g. Read for 20 minutes">
            </label>

            <label>
              Category
              <select id="offlineHabitCategory">
                <option>Personal</option>
                <option>Health</option>
                <option>Learning</option>
                <option>Productivity</option>
                <option>Mindfulness</option>
                <option>Fitness</option>
              </select>
            </label>

            <label>
              Icon
              <select id="offlineHabitIcon">
                <option value="🌱">🌱 Growth</option>
                <option value="📚">📚 Reading</option>
                <option value="💧">💧 Water</option>
                <option value="🏃">🏃 Fitness</option>
                <option value="🧘">🧘 Mindfulness</option>
                <option value="🎯">🎯 Focus</option>
                <option value="✍️">✍️ Writing</option>
                <option value="💤">💤 Sleep</option>
              </select>
            </label>
          </div>

          <div class="offline-toolbar">
            <button id="offlineSaveButton" class="button button-primary" type="submit">
              Add habit
            </button>

            <button id="offlineCancelButton" class="button button-light" type="button" hidden>
              Cancel edit
            </button>

            <button id="offlineExportButton" class="button button-light" type="button">
              Export backup
            </button>

            <label class="button button-light">
              Import backup
              <input id="offlineImportInput" type="file" accept=".json,application/json" hidden>
            </label>

            <button id="offlineReturnButton" class="button button-light" type="button">
              Return to sign in
            </button>
          </div>
        </form>

        <div id="offlineHabitList" class="offline-habit-list"></div>
      `;

      const charts = appPanel.querySelector(".charts-section");

      if (charts) {
        appPanel.insertBefore(section, charts);
      } else {
        appPanel.prepend(section);
      }

      $("#offlineHabitForm").addEventListener("submit", saveHabit);

      $("#offlineCancelButton").addEventListener("click", resetForm);

      $("#offlineExportButton").addEventListener("click", exportData);

      $("#offlineImportInput").addEventListener("change", (event) => {
        importData(event.target.files[0]);
        event.target.value = "";
      });

      $("#offlineReturnButton").addEventListener("click", closeOfflineMode);

      $("#offlineHabitList").addEventListener("click", (event) => {
        const button = event.target.closest("button[data-offline-action]");

        if (!button) return;

        const id = button.dataset.id;

        switch (button.dataset.offlineAction) {
          case "toggle":
            toggleHabit(id);
            break;

          case "edit":
            editHabit(id);
            break;

          case "delete":
            deleteHabit(id);
            break;
        }
      });
    }
  }

  function openOfflineMode() {
    const authPanel = $("#authPanel");
    const appPanel = $("#appPanel");
    const dashboard = $("#offlineDashboard");
    const signOutButton = $("#signOutButton");

    authPanel.classList.add("hidden");
    appPanel.classList.remove("hidden");

    if (signOutButton) {
      signOutButton.classList.add("hidden");
    }

    dashboard.classList.remove("hidden");
    document.body.classList.add("habitflow-offline-mode");

    renderOfflineHabits();
  }

  function closeOfflineMode() {
    document.body.classList.remove("habitflow-offline-mode");

    $("#offlineDashboard").classList.add("hidden");
    $("#appPanel").classList.add("hidden");
    $("#authPanel").classList.remove("hidden");
  }

  function initialize() {
    loadData();
    addStyles();
    createDashboard();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initialize);
  } else {
    initialize();
  }

  window.HabitFlowOffline = {
    open: openOfflineMode,
    close: closeOfflineMode,
    render: renderOfflineHabits,
    getHabits: () => state.habits.slice(),
    getCompletions: () => state.completions.slice()
  };
})();
