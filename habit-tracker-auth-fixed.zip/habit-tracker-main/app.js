
"use strict";

/* =========================================================
   HABITFLOW - COMPLETE APPLICATION ENGINE
   Calendar + Multiple Habit Marking + Supabase
   ========================================================= */

/* 1. SUPABASE CONFIGURATION */

const APP_CONFIG = window.APP_CONFIG || {};

const SUPABASE_URL = APP_CONFIG.supabaseUrl;
const SUPABASE_KEY = APP_CONFIG.supabaseAnonKey;

if (!SUPABASE_URL || !SUPABASE_KEY) {
  console.error("HabitFlow: Missing Supabase configuration.");
}

if (!window.supabase) {
  throw new Error("Supabase library failed to load.");
}

const db = window.supabase.createClient(
  SUPABASE_URL,
  SUPABASE_KEY
);

/* 2. APPLICATION STATE */

const state = {
  user: null,
  habits: [],
  completions: [],
  selectedHabits: new Set(),
  currentFilter: "all",
  editingHabit: null,
  selectedDate: localDateString(new Date()),
  calendarMonth: new Date(
    new Date().getFullYear(),
    new Date().getMonth(),
    1
  ),
  authMode: "login",
  busy: false
};

// Centralized authentication/dashboard transition state.
let pendingDashboardLoad = null;
let pendingDashboardUserId = null;
let authSubscription = null;

/* 3. DOM HELPERS */

const $ = id => document.getElementById(id);

function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, char => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;"
  })[char]);
}

function localDateString(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");

  return `${year}-${month}-${day}`;
}

function formatDate(dateString) {
  const [year, month, day] = dateString.split("-").map(Number);

  return new Date(year, month - 1, day)
    .toLocaleDateString(undefined, {
      weekday: "long",
      day: "numeric",
      month: "long",
      year: "numeric"
    });
}

function showMessage(message, type = "success") {
  const element = $("appMessage");

  if (element) {
    element.textContent = message;
    element.className = `message ${type}`;
  }

  showToast(message);
}

function showToast(message) {
  const toast = $("toast");

  if (!toast) return;

  toast.textContent = message;
  toast.classList.add("show");

  clearTimeout(showToast.timer);

  showToast.timer = setTimeout(() => {
    toast.classList.remove("show");
  }, 3000);
}

function setBusy(value) {
  state.busy = value;

  document.querySelectorAll(
    ".bulk-actions button, #addHabitButton"
  ).forEach(button => {
    button.disabled = value;
  });
}

/* 4. COMPLETION HELPERS */

function isCompleted(habitId, date = state.selectedDate) {
  return state.completions.some(record =>
    String(record.habit_id) === String(habitId) &&
    record.completed_on === date
  );
}

function getCompletedCount(date = state.selectedDate) {
  return state.habits.filter(habit =>
    isCompleted(habit.id, date)
  ).length;
}

function getProgress(date = state.selectedDate) {
  if (!state.habits.length) return 0;

  return Math.round(
    (getCompletedCount(date) / state.habits.length) * 100
  );
}

/* 5. AUTHENTICATION */

function setAuthMode(mode) {
  state.authMode = mode;

  const signup = mode === "signup";

  $("authTitle").textContent = signup
    ? "Create your account"
    : "Welcome back";

  $("authDescription").textContent = signup
    ? "Start building better habits today."
    : "Sign in to continue your journey.";

  $("authSubmit").textContent = signup
    ? "Create account"
    : "Sign in";

  $("switchPrompt").textContent = signup
    ? "Already have an account?"
    : "New to HabitFlow?";

  $("switchAuth").textContent = signup
    ? "Sign in"
    : "Create account";

  $("password").autocomplete = signup
    ? "new-password"
    : "current-password";
}

async function handleAuthentication(event) {
  event.preventDefault();

  if (state.busy) return;

  const email = $("email").value.trim();
  const password = $("password").value;

  const button = $("authSubmit");

  button.disabled = true;
  button.textContent = "Please wait...";

  $("authMessage").textContent = "";

  try {
    let result;

    if (state.authMode === "signup") {
      result = await db.auth.signUp({
        email,
        password
      });

      if (!result.error && !result.data.session) {
        $("authMessage").textContent =
          "Account created. Check your email to confirm your address before signing in.";
        $("authMessage").className = "message success";
      }

    } else {
      result = await db.auth.signInWithPassword({
        email,
        password
      });
    }

    if (result.error) throw result.error;

    if (result.data.session) {
      // The auth listener and this direct path may both observe SIGNED_IN.
      // enterAuthenticatedSession() safely prevents duplicate dashboard loads.
      await enterAuthenticatedSession(result.data.session);
    }

  } catch (error) {
    $("authMessage").textContent =
      error.message || "Authentication failed.";

    $("authMessage").className = "message error";

  } finally {
    button.disabled = false;
    button.textContent =
      state.authMode === "signup"
        ? "Create account"
        : "Sign in";
  }
}

async function signOut() {
  try {
    const { error } = await db.auth.signOut();

    if (error) throw error;

    resetApplication();

  } catch (error) {
    showToast(error.message);
  }
}

function resetApplication() {
  pendingDashboardLoad = null;
  pendingDashboardUserId = null;
  state.user = null;
  state.habits = [];
  state.completions = [];
  state.selectedHabits.clear();
  state.editingHabit = null;

  $("appPanel").classList.add("hidden");
  $("authPanel").classList.remove("hidden");
  $("signOutButton").classList.add("hidden");

  $("habitList").innerHTML = "";
}

/* 6. LOAD USER APPLICATION */

async function enterAuthenticatedSession(session) {
  const user = session && session.user;

  if (!user || !user.id) return;

  // If this account is already visible, there is nothing to initialize again.
  if (
    state.user &&
    state.user.id === user.id &&
    !$('appPanel').classList.contains('hidden')
  ) {
    return;
  }

  // Supabase can notify SIGNED_IN while the form handler is also resuming.
  // Reuse the in-flight load rather than running it twice.
  if (pendingDashboardLoad && pendingDashboardUserId === user.id) {
    return pendingDashboardLoad;
  }

  pendingDashboardUserId = user.id;
  pendingDashboardLoad = (async () => {
    try {
      await loadApplication(user);
    } catch (error) {
      console.error('HabitFlow dashboard initialization failed:', error);
      $('authMessage').textContent =
        'Your account is signed in, but the dashboard could not initialize: ' +
        (error.message || 'Unknown error');
      $('authMessage').className = 'message error';
      $('authPanel').classList.remove('hidden');
      $('appPanel').classList.add('hidden');
    } finally {
      pendingDashboardLoad = null;
      pendingDashboardUserId = null;
    }
  })();

  return pendingDashboardLoad;
}

async function loadApplication(user) {
  state.user = user;

  $("authPanel").classList.add("hidden");
  $("appPanel").classList.remove("hidden");
  $("signOutButton").classList.remove("hidden");

  const greetingName =
    user.email ? user.email.split("@")[0] : "there";

  $("greeting").textContent =
    `Welcome back, ${greetingName}! ✦`;

  $("todayLabel").textContent =
    formatDate(localDateString(new Date()));

  await loadHabits();
}

/* 7. LOAD HABITS */

async function loadHabits() {
  if (!state.user) return;

  $("loadingMessage").classList.remove("hidden");
  $("loadingMessage").textContent = "Loading your habits...";

  try {
    const { data: habits, error } = await db
      .from("habits")
      .select("*")
      .eq("user_id", state.user.id)
      .order("created_at", { ascending: true });

    if (error) throw error;

    state.habits = habits || [];

    const habitIds = state.habits.map(habit => habit.id);

    state.selectedHabits.clear();

    if (habitIds.length) {
      const { data: completions, error: completionError } =
        await db
          .from("habit_completions")
          .select("*")
          .in("habit_id", habitIds);

      if (completionError) throw completionError;

      state.completions = completions || [];

    } else {
      state.completions = [];
    }

    $("loadingMessage").classList.add("hidden");

    renderEverything();

  } catch (error) {
    $("loadingMessage").textContent =
      "Could not load your habits: " + error.message;

    showMessage(error.message, "error");
  }
}

/* 8. CREATE AND EDIT HABITS */

function openHabitForm(habit = null) {
  state.editingHabit = habit ? habit.id : null;

  $("habitForm").classList.remove("hidden");

  $("habitFormTitle").textContent = habit
    ? "Edit habit"
    : "Create a habit";

  $("habitName").value = habit?.name || "";
  $("habitCategory").value = habit?.category || "Personal";
  $("habitIcon").value = habit?.icon || "🌱";

  $("habitName").focus();
}

function closeHabitForm() {
  $("habitForm").reset();
  $("habitForm").classList.add("hidden");
  state.editingHabit = null;
}

async function saveHabit(event) {
  event.preventDefault();

  if (!state.user) return;

  const name = $("habitName").value.trim();

  if (!name) return;

  const payload = {
    name,
    category: $("habitCategory").value,
    icon: $("habitIcon").value
  };

  try {
    let result;

    if (state.editingHabit) {
      result = await db
        .from("habits")
        .update(payload)
        .eq("id", state.editingHabit)
        .eq("user_id", state.user.id);

    } else {
      result = await db
        .from("habits")
        .insert({
          ...payload,
          user_id: state.user.id
        });
    }

    if (result.error) throw result.error;

    closeHabitForm();

    await loadHabits();

    showMessage(
      state.editingHabit
        ? "Habit updated successfully."
        : "New habit added successfully."
    );

  } catch (error) {
    showMessage(error.message, "error");
  }
}

/* 9. DELETE HABIT */

async function deleteHabit(id) {
  const habit = state.habits.find(item =>
    String(item.id) === String(id)
  );

  if (!habit) return;

  if (!confirm(`Delete "${habit.name}" and its completion history?`)) {
    return;
  }

  try {
    // Delete completion history first.
    const { error: completionError } = await db
      .from("habit_completions")
      .delete()
      .eq("habit_id", id);

    if (completionError) throw completionError;

    const { error } = await db
      .from("habits")
      .delete()
      .eq("id", id)
      .eq("user_id", state.user.id);

    if (error) throw error;

    await loadHabits();

    showToast("Habit deleted.");

  } catch (error) {
    showMessage(error.message, "error");
  }
}

/* 10. COMPLETE A SINGLE HABIT */

async function setHabitCompletion(habitId, date, completed) {
  if (!state.user) return;

  if (completed) {
    const { error } = await db
      .from("habit_completions")
      .upsert(
        {
          habit_id: habitId,
          completed_on: date
        },
        {
          onConflict: "habit_id,completed_on",
          ignoreDuplicates: true
        }
      );

    if (error) throw error;

  } else {
    const { error } = await db
      .from("habit_completions")
      .delete()
      .eq("habit_id", habitId)
      .eq("completed_on", date);

    if (error) throw error;
  }
}

async function toggleHabit(habitId) {
  if (state.busy) return;

  const completed = isCompleted(habitId);

  try {
    await setHabitCompletion(
      habitId,
      state.selectedDate,
      !completed
    );

    await loadHabits();

    showToast(
      completed
        ? "Completion removed."
        : "Habit completed! 🎉"
    );

  } catch (error) {
    showMessage(error.message, "error");
  }
}

/* 11. MULTIPLE HABIT SELECTION */

function updateSelectionCount() {
  $("selectedHabitCount").textContent =
    `${state.selectedHabits.size} selected`;
}

function selectAllHabits() {
  state.habits.forEach(habit => {
    state.selectedHabits.add(String(habit.id));
  });

  renderHabits();
  updateSelectionCount();
}

function clearHabitSelection() {
  state.selectedHabits.clear();

  renderHabits();
  updateSelectionCount();
}

function toggleSelection(id, checked) {
  const key = String(id);

  if (checked) {
    state.selectedHabits.add(key);
  } else {
    state.selectedHabits.delete(key);
  }

  updateSelectionCount();
}

/* 12. COMPLETE SELECTED HABITS */

async function markSelectedHabits() {
  if (state.busy) return;

  const ids = [...state.selectedHabits];

  if (!ids.length) {
    showToast("Select at least one habit first.");
    return;
  }

  const habitsToComplete = state.habits.filter(habit =>
    ids.includes(String(habit.id)) &&
    !isCompleted(habit.id)
  );

  if (!habitsToComplete.length) {
    showToast("Selected habits are already completed.");
    return;
  }

  setBusy(true);

  try {
    const records = habitsToComplete.map(habit => ({
      habit_id: habit.id,
      completed_on: state.selectedDate
    }));

    const { error } = await db
      .from("habit_completions")
      .upsert(records, {
        onConflict: "habit_id,completed_on",
        ignoreDuplicates: true
      });

    if (error) throw error;

    state.selectedHabits.clear();

    await loadHabits();

    showToast(
      `${habitsToComplete.length} habits completed! 🎉`
    );

  } catch (error) {
    showMessage(error.message, "error");

  } finally {
    setBusy(false);
  }
}

/* 13. COMPLETE ALL HABITS */

async function markAllHabits() {
  if (state.busy) return;

  if (!state.habits.length) {
    showToast("Add habits first.");
    return;
  }

  const remaining = state.habits.filter(habit =>
    !isCompleted(habit.id)
  );

  if (!remaining.length) {
    showToast("All habits are already completed! 🎉");
    return;
  }

  setBusy(true);

  try {
    const records = remaining.map(habit => ({
      habit_id: habit.id,
      completed_on: state.selectedDate
    }));

    const { error } = await db
      .from("habit_completions")
      .upsert(records, {
        onConflict: "habit_id,completed_on",
        ignoreDuplicates: true
      });

    if (error) throw error;

    state.selectedHabits.clear();

    await loadHabits();

    showToast("All habits completed! 🏆");

  } catch (error) {
    showMessage(error.message, "error");

  } finally {
    setBusy(false);
  }
}
var records = remaining.map(function(habit) {
    return {
        habit_id: habit.id,
        user_id: state.user.id,
        completed_on: state.selectedDate
    };
});

/* 14. RENDER HABIT LIST */

function renderHabits() {
  const list = $("habitList");

  list.innerHTML = "";

  let filtered = state.habits;

  if (state.currentFilter === "todo") {
    filtered = filtered.filter(habit =>
      !isCompleted(habit.id)
    );
  }

  if (state.currentFilter === "done") {
    filtered = filtered.filter(habit =>
      isCompleted(habit.id)
    );
  }

  $("emptyMessage").classList.toggle(
    "hidden",
    filtered.length !== 0
  );

  filtered.forEach(habit => {
    const completed = isCompleted(habit.id);
    const selected = state.selectedHabits.has(
      String(habit.id)
    );

    const card = document.createElement("article");

    card.className = `habit-card ${completed ? "is-completed" : ""}`;

    card.innerHTML = `
      <input
        class="habit-select"
        type="checkbox"
        aria-label="Select ${escapeHTML(habit.name)}"
        ${selected ? "checked" : ""}
      >

      <div class="habit-main">
        <span class="habit-icon">
          ${escapeHTML(habit.icon || "🌱")}
        </span>

        <div>
          <h3>${escapeHTML(habit.name)}</h3>
          <p class="muted small">
            ${escapeHTML(habit.category || "Personal")}
            · ${completed ? "Completed ✓" : "Not completed"}
          </p>
        </div>
      </div>

      <div class="habit-actions">
        <button class="button button-light toggle-button" type="button">
          ${completed ? "Undo" : "✓ Complete"}
        </button>

        <button class="button button-light edit-button" type="button">
          Edit
        </button>

        <button class="button button-light delete-button" type="button">
          Delete
        </button>
      </div>
    `;

    card.querySelector(".habit-select")
      .addEventListener("change", event => {
        toggleSelection(habit.id, event.target.checked);
      });

    card.querySelector(".toggle-button")
      .addEventListener("click", () => {
        toggleHabit(habit.id);
      });

    card.querySelector(".edit-button")
      .addEventListener("click", () => {
        openHabitForm(habit);
      });

    card.querySelector(".delete-button")
      .addEventListener("click", () => {
        deleteHabit(habit.id);
      });

    list.appendChild(card);
  });

  updateSelectionCount();
}

/* 15. CALENDAR RENDERING */

function renderCalendar() {
  const grid = $("calendarGrid");

  grid.innerHTML = "";

  const year = state.calendarMonth.getFullYear();
  const month = state.calendarMonth.getMonth();

  $("calendarMonth").textContent =
    state.calendarMonth.toLocaleDateString(undefined, {
      month: "long",
      year: "numeric"
    });

  const weekdays = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

  weekdays.forEach(day => {
    const heading = document.createElement("div");

    heading.className = "calendar-day";
    heading.textContent = day;

    grid.appendChild(heading);
  });

  const firstDay = new Date(year, month, 1).getDay();

  const daysInMonth = new Date(
    year,
    month + 1,
    0
  ).getDate();

  const today = localDateString(new Date());

  for (let i = 0; i < firstDay; i++) {
    const blank = document.createElement("div");
    blank.className = "calendar-date empty";
    grid.appendChild(blank);
  }

  for (let day = 1; day <= daysInMonth; day++) {
    const date = localDateString(
      new Date(year, month, day)
    );

    const completedCount = getCompletedCount(date);

    const isDayCompleted =
      state.habits.length > 0 &&
      completedCount === state.habits.length;

    const button = document.createElement("button");

    button.type = "button";

    button.className = "calendar-date";

    if (date === today) button.classList.add("today");

    if (date === state.selectedDate) {
      button.classList.add("selected");
    }

    if (completedCount > 0) {
      button.classList.add("completed");
    }

    button.textContent = day;

    button.title =
      `${formatDate(date)}: ${completedCount}/${state.habits.length} habits completed`;

    if (date > today) {
      button.disabled = true;
    }

    if (isDayCompleted) {
      button.setAttribute("aria-label",
        `${day}, all habits completed`);
    }

    button.addEventListener("click", () => {
      selectCalendarDate(date);
    });

    grid.appendChild(button);
  }

  renderCalendarSummary();
}

/* 16. SELECT CALENDAR DATE */

function selectCalendarDate(date) {
  const today = localDateString(new Date());

  if (date > today) return;

  state.selectedDate = date;

  state.selectedHabits.clear();

  renderEverything();
}

/* 17. CALENDAR NAVIGATION */

function changeCalendarMonth(direction) {
  const current = state.calendarMonth;

  const next = new Date(
    current.getFullYear(),
    current.getMonth() + direction,
    1
  );

  const today = new Date();

  // Prevent navigating into future months.
  if (
    next.getFullYear() > today.getFullYear() ||
    (
      next.getFullYear() === today.getFullYear() &&
      next.getMonth() > today.getMonth()
    )
  ) {
    return;
  }

  state.calendarMonth = next;

  renderCalendar();
}

/* 18. CALENDAR SUMMARY */

function renderCalendarSummary() {
  const date = state.selectedDate;

  const completed = getCompletedCount(date);
  const total = state.habits.length;

  $("calendarSelectedDate").textContent =
    formatDate(date);

  $("calendarDaySummary").textContent =
    total === 0
      ? "Add habits to begin tracking."
      : `${completed} of ${total} habits completed · ${getProgress(date)}% progress`;
}

/* 19. STATISTICS */

function renderStatistics() {
  const today = localDateString(new Date());

  const completed = getCompletedCount(today);
  const total = state.habits.length;

  const percentage = total
    ? Math.round((completed / total) * 100)
    : 0;

  $("progressValue").textContent = `${percentage}%`;

  $("progressBar").style.width = `${percentage}%`;

  $("progressText").textContent =
    `${completed} of ${total} habits completed today`;

  $("habitCount").textContent = total;

  document.querySelector(
    '[aria-label="Today\'s habit completion"]'
  )?.setAttribute("aria-valuenow", percentage);

  renderStreak();
  renderWeeklyStats();
}

/* 20. STREAK CALCULATION */

function renderStreak() {
  if (!state.habits.length) {
    $("streakValue").textContent = "0";
    return;
  }

  let streak = 0;

  const cursor = new Date();

  // Count consecutive days where all habits were completed.
  while (true) {
    const date = localDateString(cursor);

    const completed = getCompletedCount(date);

    if (completed !== state.habits.length) break;

    streak++;

    cursor.setDate(cursor.getDate() - 1);
  }

  $("streakValue").textContent = streak;
}

/* 21. WEEKLY STATISTICS */

function renderWeeklyStats() {
  const today = new Date();

  let possible = 0;
  let completed = 0;

  for (let i = 0; i < 7; i++) {
    const date = new Date(today);

    date.setDate(today.getDate() - i);

    const dateString = localDateString(date);

    const count = getCompletedCount(dateString);

    possible += state.habits.length;
    completed += count;
  }

  const rate = possible
    ? Math.round((completed / possible) * 100)
    : 0;

  $("weeklyValue").textContent = `${rate}%`;
  $("weeklyBar").style.width = `${rate}%`;

  $("weeklyText").textContent =
    `${completed} of ${possible} possible habit completions this week.`;
}

/* 22. FILTERS */

function setFilter(filter) {
  state.currentFilter = filter;

  document.querySelectorAll("[data-filter]").forEach(button => {
    const active = button.dataset.filter === filter;

    button.classList.toggle("active", active);

    button.setAttribute("aria-pressed", String(active));
  });

  renderHabits();
}

/* 23. CHART UPDATE EVENT */

function updateCharts() {
  // Existing charts.js can listen for this event.
  window.dispatchEvent(
    new CustomEvent("habitflow:data-updated", {
      detail: {
        habits: state.habits,
        completions: state.completions
      }
    })
  );

  // Support an optional chart renderer if one exists.
  if (typeof window.renderHabitCharts === "function") {
    window.renderHabitCharts(
      state.habits,
      state.completions
    );
  }
}

/* 24. RENDER EVERYTHING */

function renderEverything() {
  renderHabits();
  renderCalendar();
  renderStatistics();
  updateCharts();
}

/* 25. EXPORT BACKUP */

function exportBackup() {
  const backup = {
    app: "HabitFlow",
    version: 2,
    exportedAt: new Date().toISOString(),
    habits: state.habits,
    completions: state.completions
  };

  const blob = new Blob(
    [JSON.stringify(backup, null, 2)],
    { type: "application/json" }
  );

  const url = URL.createObjectURL(blob);

  const link = document.createElement("a");

  link.href = url;
  link.download = `habitflow-backup-${localDateString(new Date())}.json`;

  link.click();

  URL.revokeObjectURL(url);

  showToast("Backup exported.");
}

/* 26. IMPORT BACKUP */

async function importBackup(event) {
  const file = event.target.files[0];

  if (!file) return;

  try {
    const text = await file.text();

    const backup = JSON.parse(text);

    if (
      backup.app !== "HabitFlow" ||
      !Array.isArray(backup.habits)
    ) {
      throw new Error("Invalid HabitFlow backup file.");
    }

    const idMap = new Map();

    for (const habit of backup.habits) {
      const { data, error } = await db
        .from("habits")
        .insert({
          user_id: state.user.id,
          name: habit.name,
          category: habit.category || "Personal",
          icon: habit.icon || "🌱"
        })
        .select()
        .single();

      if (error) throw error;

      idMap.set(String(habit.id), data.id);
    }

    const records = (backup.completions || [])
      .filter(item => idMap.has(String(item.habit_id)))
      .map(item => ({
        habit_id: idMap.get(String(item.habit_id)),
        completed_on: item.completed_on
      }));

    for (let i = 0; i < records.length; i += 500) {
      const { error } = await db
        .from("habit_completions")
        .upsert(records.slice(i, i + 500), {
          onConflict: "habit_id,completed_on",
          ignoreDuplicates: true
        });

      if (error) throw error;
    }

    await loadHabits();

    showToast("Backup restored successfully!");

  } catch (error) {
    showMessage(
      "Import failed: " + error.message,
      "error"
    );

  } finally {
    event.target.value = "";
  }
}

/* 27. DARK MODE */

function toggleTheme() {
  document.body.classList.toggle("dark");

  const dark = document.body.classList.contains("dark");

  $("themeButton").textContent = dark ? "☀" : "☾";

  try {
    localStorage.setItem("habitflow-theme", dark ? "dark" : "light");
  } catch (error) {
    console.warn("Theme preference could not be saved.");
  }
}

function loadTheme() {
  try {
    if (localStorage.getItem("habitflow-theme") === "dark") {
      document.body.classList.add("dark");
      $("themeButton").textContent = "☀";
    }
  } catch (error) {
    console.warn("Theme preference unavailable.");
  }
}

/* 28. PWA INSTALLATION */

let installPrompt = null;

window.addEventListener("beforeinstallprompt", event => {
  event.preventDefault();

  installPrompt = event;

  $("installButton")?.classList.remove("hidden");
});

async function installApplication() {
  if (!installPrompt) return;

  installPrompt.prompt();

  await installPrompt.userChoice;

  installPrompt = null;

  $("installButton")?.classList.add("hidden");
}

/* 29. EVENT LISTENERS */

function initializeEvents() {

  $("authForm").addEventListener(
    "submit",
    handleAuthentication
  );

  $("switchAuth").addEventListener("click", () => {
    setAuthMode(
      state.authMode === "login" ? "signup" : "login"
    );
  });

  $("signOutButton").addEventListener(
    "click",
    signOut
  );

  $("addHabitButton").addEventListener("click", () => {
    openHabitForm();
  });

  $("cancelHabitButton").addEventListener("click", () => {
    closeHabitForm();
  });

  $("habitForm").addEventListener(
    "submit",
    saveHabit
  );

  $("selectAllHabits").addEventListener(
    "click",
    selectAllHabits
  );

  $("clearHabitSelection").addEventListener(
    "click",
    clearHabitSelection
  );

  $("markSelectedHabits").addEventListener(
    "click",
    markSelectedHabits
  );

  $("markAllHabits").addEventListener(
    "click",
    markAllHabits
  );

  $("previousMonth").addEventListener("click", () => {
    changeCalendarMonth(-1);
  });

  $("nextMonth").addEventListener("click", () => {
    changeCalendarMonth(1);
  });

  document.querySelectorAll("[data-filter]").forEach(button => {
    button.addEventListener("click", () => {
      setFilter(button.dataset.filter);
    });
  });

  $("themeButton").addEventListener(
    "click",
    toggleTheme
  );

  $("exportBackup").addEventListener(
    "click",
    exportBackup
  );

  $("importBackup").addEventListener(
    "change",
    importBackup
  );

  $("installButton").addEventListener(
    "click",
    installApplication
  );
}

/* 30. APPLICATION STARTUP */

async function initializeApplication() {
  initializeEvents();
  loadTheme();
  setAuthMode("login");

  // Register the listener before reading the stored session. This avoids a
  // gap in which an auth-state change could otherwise be missed.
  const { data: listenerData, error: listenerError } =
    db.auth.onAuthStateChange((event, session) => {
      if (event === "SIGNED_OUT") {
        resetApplication();
        return;
      }

      if (session && session.user) {
        // Do not await Supabase work inside its auth callback.
        setTimeout(() => {
          enterAuthenticatedSession(session).catch(error => {
            console.error('HabitFlow auth transition failed:', error);
          });
        }, 0);
      }
    });

  if (listenerError) {
    console.error('HabitFlow auth listener error:', listenerError);
  }

  authSubscription = listenerData && listenerData.subscription
    ? listenerData.subscription
    : null;

  try {
    const { data, error } = await db.auth.getSession();
    if (error) throw error;

    if (data && data.session && data.session.user) {
      await enterAuthenticatedSession(data.session);
    } else {
      resetApplication();
    }
  } catch (error) {
    console.error("Session initialization error:", error);
    $('authMessage').textContent =
      'Could not restore your session: ' +
      (error.message || 'Please sign in again.');
    $('authMessage').className = 'message error';
    resetApplication();
  }
}

if (document.readyState === "loading") {
  document.addEventListener(
    "DOMContentLoaded",
    initializeApplication
  );
} else {
  initializeApplication();
}
