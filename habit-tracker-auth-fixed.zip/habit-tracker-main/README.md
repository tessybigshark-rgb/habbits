# HabitFlow Advanced

A responsive habit tracker built with HTML, CSS, JavaScript, and Supabase.

## Features

- Sign up and sign in with Supabase Auth
- Create, edit, complete, and delete habits
- Daily completion tracking
- Current activity streak
- Seven-day completion chart
- Dark mode
- Export habits as JSON
- Responsive mobile layout
- Local demo mode before Supabase configuration

## Setup

1. Create a Supabase project.
2. Open the SQL Editor.
3. Run `supabase-schema.sql`.
4. Copy your project URL and publishable key.
5. Paste them into `config.js`.
6. Set your Supabase Auth Site URL and allowed redirect URLs
   to your deployed Vercel domain.
7. Upload all frontend files into the same deployment directory.
8. Deploy the project through Vercel.

## Vercel settings

Framework Preset: Other
Build Command: leave blank
Output Directory: .
Install Command: leave blank

Set Root Directory to the folder containing `index.html`.

## Security

- Never put a Supabase service-role key in frontend code.
- Keep Row Level Security enabled.
- Run the supplied SQL in your own Supabase project.
- Test account isolation before using real personal data.

## Existing data

Local demo data is stored in the browser. It is not automatically migrated
to Supabase. Export any important existing data before replacing your app.
