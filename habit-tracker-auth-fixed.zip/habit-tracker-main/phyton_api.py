
from pathlib import Path
import json

from flask import Flask, jsonify, request

app = Flask(__name__)

DATA_DIR = Path(__file__).parent / "data"
DATA_FILE = DATA_DIR / "habits.json"
MAX_HABITS = 500


def read_habits():
    DATA_DIR.mkdir(parents=True, exist_ok=True)

    if not DATA_FILE.exists():
        DATA_FILE.write_text("[]", encoding="utf-8")

    try:
        data = json.loads(DATA_FILE.read_text(encoding="utf-8"))
        return data if isinstance(data, list) else []
    except (json.JSONDecodeError, OSError):
        return []


@app.get("/api/habits")
def get_habits():
    return jsonify({
        "success": True,
        "habits": read_habits()
    })


@app.post("/api/habits")
def save_habits():
    payload = request.get_json(silent=True)

    if not isinstance(payload, dict):
        return jsonify({
            "success": False,
            "error": "A JSON object is required."
        }), 400

    habits = payload.get("habits")

    if not isinstance(habits, list):
        return jsonify({
            "success": False,
            "error": "The habits field must be a list."
        }), 400

    if len(habits) > MAX_HABITS:
        return jsonify({
            "success": False,
            "error": "Too many habits."
        }), 413

    if not all(isinstance(habit, dict) for habit in habits):
        return jsonify({
            "success": False,
            "error": "Every habit must be an object."
        }), 400

    DATA_DIR.mkdir(parents=True, exist_ok=True)

    try:
        DATA_FILE.write_text(
            json.dumps(habits, ensure_ascii=False, indent=2),
            encoding="utf-8"
        )
    except OSError:
        return jsonify({
            "success": False,
            "error": "Could not save habits."
        }), 500

    return jsonify({
        "success": True,
        "message": "Habits saved successfully."
    })


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
