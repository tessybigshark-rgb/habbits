
<?php
header("Content-Type: application/json; charset=utf-8");
header("Cache-Control: no-store");

$allowedOrigin = "http://localhost:8000";
$origin = $_SERVER["HTTP_ORIGIN"] ?? "";

if ($origin === $allowedOrigin) {
    header("Access-Control-Allow-Origin: " . $allowedOrigin);
}

header("Vary: Origin");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(204);
    exit;
}

$dataDir = __DIR__ . "/data";
$dataFile = $dataDir . "/habits.json";

if (!is_dir($dataDir)) {
    mkdir($dataDir, 0750, true);
}

if (!file_exists($dataFile)) {
    file_put_contents($dataFile, "[]", LOCK_EX);
}

function respond($status, $body) {
    http_response_code($status);
    echo json_encode($body, JSON_PRETTY_PRINT);
    exit;
}

$method = $_SERVER["REQUEST_METHOD"];

if ($method === "GET") {
    $content = file_get_contents($GLOBALS["dataFile"]);
    $habits = json_decode($content, true);

    respond(200, [
        "success" => true,
        "habits" => is_array($habits) ? $habits : []
    ]);
}

if ($method === "POST") {
    $raw = file_get_contents("php://input");
    $payload = json_decode($raw, true);

    if (!is_array($payload) || !isset($payload["habits"]) ||
        !is_array($payload["habits"])) {
        respond(400, [
            "success" => false,
            "error" => "Send a JSON object containing a habits array."
        ]);
    }

    if (count($payload["habits"]) > 500) {
        respond(413, [
            "success" => false,
            "error" => "Too many habits."
        ]);
    }

    $json = json_encode(
        array_values($payload["habits"]),
        JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE
    );

    $saved = file_put_contents(
        $GLOBALS["dataFile"],
        $json,
        LOCK_EX
    );

    if ($saved === false) {
        respond(500, [
            "success" => false,
            "error" => "Could not save habits."
        ]);
    }

    respond(200, [
        "success" => true,
        "message" => "Habits saved successfully."
    ]);
}

header("Allow: GET, POST, OPTIONS");

respond(405, [
    "success" => false,
    "error" => "Method not allowed."
]);
