"use strict";

// ==========================================
// HABITFLOW SERVICE WORKER
// Version 4 — Updated cache management
// ==========================================

const CACHE_NAME = "habitflow-shell-v5";

const APP_SHELL = [
  "/",
  "/index.html",
  "/style.css",
  "/app.js",
    "/charts.js",
  "/config.js",
  "/offline.js",
];

// ==========================================
// INSTALL: Cache essential application files
// ==========================================

self.addEventListener("install", (event) => {
  event.waitUntil(
    (async () => {
      const cache = await caches.open(CACHE_NAME);

      // Cache each file independently so one missing
      // resource does not prevent installation.
      await Promise.all(
        APP_SHELL.map(async (url) => {
          try {
            const response = await fetch(url, {
              cache: "reload"
            });

            if (response.ok) {
              await cache.put(url, response);
            } else {
              console.warn(
                "HabitFlow: Could not cache",
                url,
                response.status
              );
            }
          } catch (error) {
            console.warn(
              "HabitFlow: Caching failed for",
              url,
              error
            );
          }
        })
      );

      // Activate the updated service worker promptly.
      await self.skipWaiting();
    })()
  );
});

// ==========================================
// ACTIVATE: Remove outdated caches
// ==========================================

self.addEventListener("activate", (event) => {
  event.waitUntil(
    (async () => {
      const cacheNames = await caches.keys();

      await Promise.all(
        cacheNames.map(async (cacheName) => {
          if (
            cacheName.startsWith("habitflow-shell-") &&
            cacheName !== CACHE_NAME
          ) {
            await caches.delete(cacheName);
          }
        })
      );

      // Take control of open HabitFlow pages.
      await self.clients.claim();
    })()
  );
});

// ==========================================
// FETCH: Network first, cache as fallback
// ==========================================

self.addEventListener("fetch", (event) => {
  const request = event.request;

  // Only handle GET requests.
  if (request.method !== "GET") {
    return;
  }

  const requestURL = new URL(request.url);

  // Do not intercept external requests, including
  // Supabase API requests and external CDNs.
  if (requestURL.origin !== self.location.origin) {
    return;
  }

  // Do not cache Supabase authentication or API routes.
  if (
    requestURL.pathname.startsWith("/auth/") ||
    requestURL.pathname.startsWith("/rest/") ||
    requestURL.pathname.startsWith("/storage/") ||
    requestURL.pathname.startsWith("/functions/")
  ) {
    return;
  }

  // Avoid caching preview or deployment-specific
  // Vercel internal endpoints.
  if (
    requestURL.pathname.startsWith("/_vercel/") ||
    requestURL.pathname.startsWith("/api/")
  ) {
    return;
  }

  event.respondWith(
    (async () => {
      const cache = await caches.open(CACHE_NAME);

      try {
        // Try the network first to obtain the latest files.
        const response = await fetch(request);

        // Cache successful same-origin GET responses.
        if (response.ok && response.type === "basic") {
          await cache.put(request, response.clone());
        }

        return response;
      } catch (error) {
        // If offline, try the exact cached request.
        const cachedResponse = await cache.match(request);

        if (cachedResponse) {
          return cachedResponse;
        }

        // For an offline page navigation, use the
        // cached application homepage as a fallback.
        if (request.mode === "navigate") {
          const homepage = await cache.match("/");

          if (homepage) {
            return homepage;
          }
        }

        // Provide a readable response if no cached
        // resource is available.
        if (request.destination === "document") {
          return new Response(
            "HabitFlow is currently unavailable offline. Please reconnect and try again.",
            {
              status: 503,
              headers: {
                "Content-Type": "text/plain; charset=utf-8"
              }
            }
          );
        }

        return new Response("Resource unavailable offline.", {
          status: 503,
          headers: {
            "Content-Type": "text/plain; charset=utf-8"
          }
        });
      }
    })()
  );
});
