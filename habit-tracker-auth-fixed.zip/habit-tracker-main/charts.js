
"use strict";

/* =========================================================
   HABITFLOW PART 4
   OFFLINE DATABASE + SYNC QUEUE
   Uses IndexedDB. No external library required.
   ========================================================= */

window.HabitFlowOffline = (function () {

    const DB_NAME = "habitflow_offline_v1";
    const DB_VERSION = 1;

    let database = null;

    /* -----------------------------------------------------
       OPEN DATABASE
    ----------------------------------------------------- */

    function openDatabase() {
        return new Promise((resolve, reject) => {

            if (database) {
                resolve(database);
                return;
            }

            if (!("indexedDB" in window)) {
                reject(new Error("IndexedDB is not supported."));
                return;
            }

            const request = indexedDB.open(DB_NAME, DB_VERSION);

            request.onupgradeneeded = function (event) {
                const db = event.target.result;

                if (!db.objectStoreNames.contains("snapshots")) {
                    db.createObjectStore("snapshots", {
                        keyPath: "userId"
                    });
                }

                if (!db.objectStoreNames.contains("outbox")) {
                    const outbox = db.createObjectStore("outbox", {
                        keyPath: "id",
                        autoIncrement: true
                    });

                    outbox.createIndex("userId", "userId", {
                        unique: false
                    });
                }
            };

            request.onsuccess = function (event) {
                database = event.target.result;

                database.onversionchange = function () {
                    database.close();
                    database = null;
                };

                resolve(database);
            };

            request.onerror = function () {
                reject(request.error);
            };
        });
    }

    /* -----------------------------------------------------
       TRANSACTION HELPER
    ----------------------------------------------------- */

    async function transaction(storeName, mode, callback) {
        const db = await openDatabase();

        return new Promise((resolve, reject) => {
            const tx = db.transaction(storeName, mode);
            const store = tx.objectStore(storeName);

            let result;

            try {
                result = callback(store);
            } catch (error) {
                reject(error);
                return;
            }

            tx.oncomplete = function () {
                resolve(result && result.result);
            };

            tx.onerror = function () {
                reject(tx.error);
            };

            tx.onabort = function () {
                reject(tx.error || new Error("Transaction aborted."));
            };
        });
    }

    function requestResult(request) {
        return new Promise((resolve, reject) => {
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    /* -----------------------------------------------------
       SNAPSHOT STORAGE
    ----------------------------------------------------- */

    async function saveSnapshot(userId, habits, completions) {
        if (!userId) {
            throw new Error("A user ID is required.");
        }

        const db = await openDatabase();

        return new Promise((resolve, reject) => {
            const tx = db.transaction("snapshots", "readwrite");

            tx.objectStore("snapshots").put({
                userId,
                habits: Array.isArray(habits) ? habits : [],
                completions: Array.isArray(completions)
                    ? completions
                    : [],
                updatedAt: new Date().toISOString()
            });

            tx.oncomplete = () => resolve(true);
            tx.onerror = () => reject(tx.error);
        });
    }

    async function getSnapshot(userId) {
        if (!userId) return null;

        const db = await openDatabase();

        return new Promise((resolve, reject) => {
            const tx = db.transaction("snapshots", "readonly");

            const request = tx.objectStore("snapshots").get(userId);

            request.onsuccess = () => resolve(request.result || null);
            request.onerror = () => reject(request.error);
        });
    }

    /* -----------------------------------------------------
       OUTBOX: QUEUE OFFLINE CHANGES
    ----------------------------------------------------- */

    async function queueAction(userId, action) {
        if (!userId) {
            throw new Error("You must be signed in to queue changes.");
        }

        const db = await openDatabase();

        return new Promise((resolve, reject) => {
            const tx = db.transaction("outbox", "readwrite");

            const request = tx.objectStore("outbox").add({
                userId,
                action,
                createdAt: new Date().toISOString()
            });

            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    async function getPendingActions(userId) {
        const db = await openDatabase();

        return new Promise((resolve, reject) => {
            const tx = db.transaction("outbox", "readonly");
            const request = tx.objectStore("outbox")
                .index("userId")
                .getAll(userId);

            request.onsuccess = () => {
                resolve(
                    (request.result || []).sort((a, b) => a.id - b.id)
                );
            };

            request.onerror = () => reject(request.error);
        });
    }

    async function removeAction(id) {
        const db = await openDatabase();

        return new Promise((resolve, reject) => {
            const tx = db.transaction("outbox", "readwrite");

            tx.objectStore("outbox").delete(id);

            tx.oncomplete = () => resolve(true);
            tx.onerror = () => reject(tx.error);
        });
    }

    /* -----------------------------------------------------
       OFFLINE HABIT OPERATIONS
    ----------------------------------------------------- */

    function makeLocalId() {
        if (window.crypto && crypto.randomUUID) {
            return "local-" + crypto.randomUUID();
        }

        return "local-" + Date.now() + "-" +
            Math.random().toString(16).slice(2);
    }

    async function addHabitOffline(userId, habit) {
        const snapshot = await getSnapshot(userId);

        const habits = snapshot ? [...snapshot.habits] : [];
        const completions = snapshot ? [...snapshot.completions] : [];

        const localHabit = {
            id: makeLocalId(),
            user_id: userId,
            name: habit.name,
            category: habit.category || "Personal",
            icon: habit.icon || "⭐",
            created_at: new Date().toISOString(),
            _offline: true
        };

        habits.push(localHabit);

        await saveSnapshot(userId, habits, completions);

        await queueAction(userId, {
            type: "create_habit",
            localId: localHabit.id,
            habit: {
                name: localHabit.name,
                category: localHabit.category,
                icon: localHabit.icon
            }
        });

        return localHabit;
    }

    async function deleteHabitOffline(userId, habitId) {
        const snapshot = await getSnapshot(userId);

        if (!snapshot) return false;

        const habits = snapshot.habits.filter(
            habit => habit.id !== habitId
        );

        const completions = snapshot.completions.filter(
            item => item.habit_id !== habitId
        );

        await saveSnapshot(userId, habits, completions);

        await queueAction(userId, {
            type: "delete_habit",
            habitId
        });

        return true;
    }

    async function setCompletionOffline(
        userId,
        habitId,
        date,
        completed
    ) {
        const snapshot = await getSnapshot(userId);

        const habits = snapshot ? [...snapshot.habits] : [];

        if (!habits.some(habit => habit.id === habitId)) {
            throw new Error("Habit not found in offline storage.");
        }

        let completions = snapshot
            ? [...snapshot.completions]
            : [];

        completions = completions.filter(item =>
            !(
                item.habit_id === habitId &&
                item.completed_on === date
            )
        );

        if (completed) {
            completions.push({
                habit_id: habitId,
                completed_on: date
            });
        }

        await saveSnapshot(userId, habits, completions);

        await queueAction(userId, {
            type: "set_completion",
            habitId,
            date,
            completed: Boolean(completed)
        });

        return true;
    }

    /* -----------------------------------------------------
       SYNC PENDING CHANGES TO SUPABASE
    ----------------------------------------------------- */

    async function sync(db, userId) {
        if (!navigator.onLine) {
            return {
                synced: 0,
                pending: true,
                message: "You are offline."
            };
        }

        if (!db || !userId) {
            throw new Error("Supabase or user session is missing.");
        }

        const pending = await getPendingActions(userId);

        const idMap = {};
        let synced = 0;

        for (const item of pending) {
            const action = item.action;

            try {
                if (action.type === "create_habit") {

                    const { data, error } = await db
                        .from("habits")
                        .insert({
                            user_id: userId,
                            name: action.habit.name,
                            category: action.habit.category,
                            icon: action.habit.icon
                        })
                        .select()
                        .single();

                    if (error) throw error;

                    idMap[action.localId] = data.id;
                }

                else if (action.type === "set_completion") {

                    let habitId = action.habitId;

                    if (idMap[habitId]) {
                        habitId = idMap[habitId];
                    }

                    if (String(habitId).startsWith("local-")) {
                        const remaining = await getPendingActions(userId);

                        const createAction = remaining.find(
                            entry =>
                                entry.action.type === "create_habit" &&
                                entry.action.localId === habitId
                        );

                        if (createAction) {
                            throw new Error(
                                "The new habit has not synchronized yet."
                            );
                        }

                        throw new Error(
                            "Could not find the server ID for this habit."
                        );
                    }

                    if (action.completed) {
                        const { error } = await db
                            .from("habit_completions")
                            .upsert({
                                habit_id: habitId,
                                completed_on: action.date
                            }, {
                                onConflict: "habit_id,completed_on"
                            });

                        if (error) throw error;

                    } else {
                        const { error } = await db
                            .from("habit_completions")
                            .delete()
                            .eq("habit_id", habitId)
                            .eq("completed_on", action.date);

                        if (error) throw error;
                    }
                }

                else if (action.type === "delete_habit") {

                    let habitId = action.habitId;

                    if (idMap[habitId]) {
                        habitId = idMap[habitId];
                    }

                    if (String(habitId).startsWith("local-")) {
                        // A habit created and deleted before sync
                        // does not need to be created on the server.
                    } else {
                        const { error } = await db
                            .from("habits")
                            .delete()
                            .eq("id", habitId)
                            .eq("user_id", userId);

                        if (error) throw error;
                    }
                }

                else {
                    throw new Error(
                        "Unknown offline action: " + action.type
                    );
                }

                await removeAction(item.id);
                synced++;

            } catch (error) {
                console.error(
                    "HabitFlow sync stopped at action:",
                    item,
                    error
                );

                // Keep this action and all later actions for retry.
                break;
            }
        }

        return {
            synced,
            pending: (await getPendingActions(userId)).length > 0,
            message: synced
                ? `${synced} change(s) synchronized.`
                : "No changes synchronized."
        };
    }

    /* -----------------------------------------------------
       PUBLIC API
    ----------------------------------------------------- */

    return {
        openDatabase,
        saveSnapshot,
        getSnapshot,
        queueAction,
        getPendingActions,
        addHabitOffline,
        deleteHabitOffline,
        setCompletionOffline,
        sync
    };

})();
