
from datetime import date, timedelta
from pathlib import Path
import json

DATA_FILE = Path(__file__).parent / "data" / "habits.json"


def load_habits():
    if not DATA_FILE.exists():
        return []

    try:
        data = json.loads(DATA_FILE.read_text(encoding="utf-8"))
        return data if isinstance(data, list) else []
    except (json.JSONDecodeError, OSError):
        return []


def weekly_report(habits):
    today = date.today()
    print("\nHABITFLOW — WEEKLY REPORT")
    print("=" * 35)

    for offset in range(6, -1, -1):
        current = today - timedelta(days=offset)
        date_string = current.isoformat()

        completed = sum(
            1 for habit in habits
            if date_string in habit.get("completedDates", [])
        )

        total = len(habits)
        percentage = round(completed / total * 100) if total else 0

        print(
            f"{current.strftime('%a %d %b')}: "
            f"{completed}/{total} habits — {percentage}%"
        )

    print("=" * 35)
    print(f"Total habits tracked: {len(habits)}")


if __name__ == "__main__":
    weekly_report(load_habits())
