
create extension if not exists pgcrypto;

create table if not exists public.habits (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null check (char_length(name) between 1 and 80),
  category text not null default 'Personal',
  icon text not null default '🌱',
  created_at timestamptz not null default now()
);

create table if not exists public.habit_completions (
  id uuid primary key default gen_random_uuid(),
  habit_id uuid not null references public.habits(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  completed_on date not null default current_date,
  created_at timestamptz not null default now(),
  constraint unique_habit_completion unique (habit_id, completed_on)
);

create index if not exists habits_user_id_idx
  on public.habits(user_id);

create index if not exists habit_completions_user_date_idx
  on public.habit_completions(user_id, completed_on);

alter table public.habits enable row level security;
alter table public.habit_completions enable row level security;

drop policy if exists "Users can view their own habits"
  on public.habits;
create policy "Users can view their own habits"
  on public.habits for select
  using (auth.uid() = user_id);

drop policy if exists "Users can add their own habits"
  on public.habits;
create policy "Users can add their own habits"
  on public.habits for insert
  with check (auth.uid() = user_id);

drop policy if exists "Users can update their own habits"
  on public.habits;
create policy "Users can update their own habits"
  on public.habits for update
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

drop policy if exists "Users can delete their own habits"
  on public.habits;
create policy "Users can delete their own habits"
  on public.habits for delete
  using (auth.uid() = user_id);

drop policy if exists "Users can view their own completions"
  on public.habit_completions;
create policy "Users can view their own completions"
  on public.habit_completions for select
  using (auth.uid() = user_id);

drop policy if exists "Users can add their own completions"
  on public.habit_completions;
create policy "Users can add their own completions"
  on public.habit_completions for insert
  with check (
    auth.uid() = user_id
    and exists (
      select 1
      from public.habits h
      where h.id = habit_id
        and h.user_id = auth.uid()
    )
  );

drop policy if exists "Users can delete their own completions"
  on public.habit_completions;
create policy "Users can delete their own completions"
  on public.habit_completions for delete
  using (auth.uid() = user_id);
